import java.util.Scanner;

public class Joueur {
    public static int choixJoueur1;
    public static int choixJoueur2;
    public static String[] joueurs;

    public Joueur() {
        saisieNomJoueur();//Appel de la méthode de saisie du nom des joueurs
        saisieChoixJoueur();//Appel de la méthode de saisie du choix des joueurs
    }

    public void saisieNomJoueur(){//Les joueurs n'ont pas de restrictions pour le choix de leur nom
        Scanner clavier = new Scanner(System.in);

        System.out.print(Affichage.SAISIR_NOM_JOUEUR + 1 + Affichage.ESPACE + Affichage.EMOJI_FINGER);
        joueurs = new String[]{clavier.next(), ""};

        System.out.print(Affichage.SAISIR_NOM_JOUEUR + 2 + Affichage.ESPACE + Affichage.EMOJI_FINGER);
        joueurs[1] = clavier.next();
    }

    public void saisieChoixJoueur(){//Les joueurs ne peuvent taper que 0 ou 1 pour chosir pile ou face
        Scanner clavier = new Scanner(System.in);

        System.out.print(joueurs[0] + Affichage.SAISIR_CHOIX_JOUEUR + Affichage.EMOJI_FINGER);
        choixJoueur1 = clavier.nextInt();

        while(choixJoueur1 < 0 || choixJoueur1 > 1){
            System.out.print(joueurs[0] + Affichage.SAISIR_CHOIX_JOUEUR + Affichage.EMOJI_FINGER);
            choixJoueur1 = clavier.nextInt();
        }

        System.out.print(joueurs[1] + Affichage.SAISIR_CHOIX_JOUEUR + Affichage.EMOJI_FINGER);
        choixJoueur2 = clavier.nextInt();

        while(choixJoueur2 < 0 ||choixJoueur2 > 1){
            System.out.print(joueurs[1] + Affichage.SAISIR_CHOIX_JOUEUR + Affichage.EMOJI_FINGER);
            choixJoueur2 = clavier.nextInt();
        }
    }

    public static void gagnantJoueur(){
        if(choixJoueur1 == 0 && choixJoueur2 == 1 && Piece.sommeResult < 6){//Si J1 a choisi pile, J2 face et plus de pile que de face
            System.out.println(Affichage.GAGNANT + joueurs[0] + Affichage.EMOJI_CLAP);//Alors J1 gagne

        } else if (choixJoueur1 == 1 && choixJoueur2 == 0 && Piece.sommeResult > 5){//Si J1 choisi face, J2 pile et plus de face que de pile
            System.out.println(Affichage.GAGNANT + joueurs[0] + Affichage.EMOJI_CLAP);//Alors J1 gagne

        } else if (choixJoueur1 == 0 && choixJoueur2 == 1 && Piece.sommeResult > 5){//Si J1 choisi pile, J2 face et plus de face que de pile
            System.out.println(Affichage.GAGNANT + joueurs[1] + Affichage.EMOJI_CLAP);//Alors J2 gagne

        } else if (choixJoueur1 == 0 && choixJoueur2 == 0 && Piece.sommeResult > 5){//Si J1 et J2 choisissent pile et plus de face que de pile
            System.out.println(Affichage.PERDANTS + Affichage.EMOJI_GRIMACE);//Alors J1 et J2 perdent

        } else if (choixJoueur1 == 1 && choixJoueur2 == 1 && Piece.sommeResult < 6){//Si J1 et J2 choisissent face et plus de pile que de face
            System.out.println(Affichage.PERDANTS + Affichage.EMOJI_GRIMACE);//Alors J1 et J2 perdent

        } else {
            System.out.println(Affichage.GAGNANTS + Affichage.EMOJI_CROWN + Affichage.EMOJI_CROWN);//Sinon J1 et J2 gagnent
        }
    }
}
