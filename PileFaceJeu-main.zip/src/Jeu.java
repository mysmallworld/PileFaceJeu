public class Jeu {

    public static int tour = 0;//Nombre de tour initialisé à 0

     public static void jeu() {
       Joueur joueur = new Joueur();//Instance de Joueur
         System.out.print("Voici le resultat sur 11 tours : ");
         while(tour < 11){//Attention si le nombre de tour est changé il faudra aussi changer la condition liée à sommeResult dans la méthode tourVictoire
             Piece piece = new Piece();//Instance de piece
             tour++;//On ajoute un tour à chaque lancé
         }
         System.out.println();

       Piece.tourVictoire();//Appel de la methode pour vérifier la somme des piles et des faces

       Joueur.gagnantJoueur();//Appel de la methode pour désigner le joueur gagnant ou perdant
     }

    public static void main(String[] args) {
         jeu();//Appel de la méthode jeu
    }
}
