public class Affichage {
    public static final String SAISIR_NOM_JOUEUR = "Veuillez saisir le nom du joueur ";
    public static final String SAISIR_CHOIX_JOUEUR = " tapez : 0 pour pile \u26AB | 1 pour face\u26AA ";
    public static final String GAGNANT = "Vous avez gagné joueur ";
    public static final String GAGNANTS = "Vous avez tous les deux gagnés ";
    public static final String PERDANTS = "Vous avez tous les deux perdus ";
    public static final String ESPACE = " ";

    public static final String EMOJI_FINGER = "\uD83D\uDC49";
    public static final String EMOJI_CROWN = "\uD83D\uDC51";
    public static final String EMOJI_CLAP = "\uD83D\uDC4F";
    public static final String EMOJI_GRIMACE = "\uD83D\uDE35";
    public static final String EMOJI_BLACK_CIRCLE = "\u26AB";
    public static final String EMOJI_WHITE_CIRCLE = "\u26AA";
}
