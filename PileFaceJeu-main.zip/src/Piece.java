import java.util.Random;

public class Piece {
     public int pile = 0;
     public int face = 1;
     public static int sommeResult;

     public Piece(){
          Random rand = new Random();
          int result = rand.nextInt(2);
          int[] tabResult = {result};//Insertion de tous les piles et faces dans un tableau
          for(int i : tabResult){//Somme du tableau des piles et des faces
               sommeResult = sommeResult + i;
          }
          if(result == pile){
               System.out.print(Affichage.EMOJI_BLACK_CIRCLE);
          }else if (result == face){
               System.out.print(Affichage.EMOJI_WHITE_CIRCLE);
          } else {
               System.out.println("La pièce a un problème !");
          }
     }

     public static void tourVictoire(){
          if(sommeResult < 6){//Si la somme des piles et des faces < 5, face sera inférieur à la moitié des tours
               System.out.println("Pile est sortie plus de fois que Face !");//Alors il y aura plus de pile que de face
          } else if(sommeResult > 5){//Si la somme des piles et des faces > 5, face sera au moins égal à 6 (sur 11 tours)
               System.out.println("Face est sortie plus de fois que Pile !" );
          } else {
               System.out.println("Face est sortie autant de fois que Pile !");//Dans l'hypothèse d'un nombre de tour pair
          }
     }
}
