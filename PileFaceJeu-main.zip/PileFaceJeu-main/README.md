# PileFaceJeu
Le pile ou face est un jeu de hasard se jouant avec une pièce de monnaie. 
Le principe du jeu est de lancer en l'air une pièce équilibrée et de parier sur le côté sorti.

Ce programme (JAVA) se compose de deux joueurs et se déroule sur plusieurs étapes :
1. Le joueur 1 saisi son nom ;
2. Le joueur 2 saisi son nom ;
Info : Les joueurs n'ont pas de restrictions sur leur nom. 

3. Le joueur 1 choisi pile(en tapant 0) ou face(en tapant 1);
4. Le joueur 2 choisi pile(en tapant 0) ou face(en tapant 1);
Info : Les joueurs peuvent tous les deux choisir la même chose. 
Par conséquent, ils peuvent soit tous les deux perdre, soit tous les deux gagner.

5. Le programme s'exécute sur 11 tours(ou lancés) et affiche sur trois lignes :
-la liste des résultats sur les 11 tours ;
-la face de la pièce qui est le plus resortie ;
-le nom du gagnant (ou si les deux joueurs ont perdus ou gagnés). 
